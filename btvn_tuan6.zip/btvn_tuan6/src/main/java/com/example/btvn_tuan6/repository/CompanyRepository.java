package com.example.btvn_tuan6.repository;

import com.example.btvn_tuan6.models.Company;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyRepository extends JpaRepository<Company,Long> {
}
