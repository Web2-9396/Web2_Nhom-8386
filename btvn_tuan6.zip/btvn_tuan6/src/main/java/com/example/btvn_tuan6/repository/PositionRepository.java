package com.example.btvn_tuan6.repository;

import com.example.btvn_tuan6.models.Position;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PositionRepository extends JpaRepository<Position,Long> {
}
