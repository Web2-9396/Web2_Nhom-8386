package com.example.btvn_tuan6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtvnTuan6Application {

	public static void main(String[] args) {
		SpringApplication.run(BtvnTuan6Application.class, args);
	}

}
