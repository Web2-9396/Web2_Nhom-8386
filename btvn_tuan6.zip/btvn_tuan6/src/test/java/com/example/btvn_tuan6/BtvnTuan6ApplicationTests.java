package com.example.btvn_tuan6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtvnTuan6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
